# Who Cares Software theme

Design tokens and generated themes for Who Cares Software.
**Experimental palette: dark muted foundations with rose and orchid candidates.**
Initial colors take inspiration from Nocturne Rose. The founder selected orchid
(`#B69ACB`) as the primary accent after reviewing the comparison. Remaining
semantic roles and supporting colors are experimental; rose is a secondary candidate.

## Ownership

- [Brand repository](../README.md): unified ownership of story, assets, rationale,
  approval and this theme workspace.
- Here: canonical machine-readable palette, semantic roles, adapters and generators.
- Consumers: their application behavior and normal theme activation.

## Build and verify

Node 22 or later; no dependencies to install.

```sh
npm run build
npm test
npm run check
```

These commands run from this workspace. From the repository root, the same
commands build/check theme then identity and run the theme tests. The former
Taskfile wrappers are consolidated into these npm scripts.
Generation is independent of the caller's directory and never reads consumer settings.

## Layout and contract

- `tokens/whocares.json`: named hex colors and semantic roles referencing palette keys.
- `tokens/website.json`: website palette extensions, light/dark roles and color recipes.
  Base palette names cannot be overridden. Mode roles must match and references
  must resolve. Generated `dist/website.{css,json}` is the website color interface.
- `scripts/`: runtime validation, reference resolution, rendering and freshness checks.
- `adapters/**/*.tmpl`: templates using `{{palette.rose}}` or `{{semantic.accent}}`.
- `dist/`: ignored, untracked JSON, CSS, ESM, TypeScript declarations and adapter outputs.

Token keys use kebab-case consistently. CSS primitives use `--wcs-palette-*`;
semantic variables use `--wcs-*`. Applications should prefer semantic roles.
JSON and JS include metadata and resolved palette/semantic groups.
Only `.tmpl` files are rendered, preserving their relative path minus that suffix.
Unknown references, malformed placeholders, duplicate outputs, and retired files fail.
Remove retired files explicitly after review. Check mode never writes.

Open `dist/preview/index.html` for a rose-versus-orchid comparison.
Preview typography and spacing are illustrative, not brand tokens.
The base theme provides dark color tokens; the website adapter provides both
light and dark treatments, including system-preference fallback. Theme owns all
executable color values; brand documents why they were chosen and consumes tokens
to generate identity assets. Consumer-owned imports never run from this generator.

The private `@whocaressoftware/theme` package exports `.`, `./css`, `./tokens.json`,
`./website.css` and `./website.json`. It is distributed as an `npm pack` archive;
prepack builds the workspace. Version 0.4.0 is coordinated with the root brand
package. See [release commands](../README.md#coordinated-releases). Generated
outputs are never committed; consumers install the packaged outputs.
