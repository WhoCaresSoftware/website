# Who Cares Software — brand

**Who cares? We do.**

The canonical home for our studio story, identity decisions, design tokens,
theme generators and current assets. One repository owns both private packages:
`@whocaressoftware/brand` at the root and `@whocaressoftware/theme` in `theme/`.

- [Documentation](docs/) · [Studio profile](docs/PROFILE.md)
- [Identity decisions](docs/DECISIONS.md) · [Usage guide](docs/USAGE.md)
- [Source assets and provenance](assets/README.md)
- [Theme workspace](theme/README.md) · [Color ownership](docs/COLOR-OWNERSHIP.md)
- After building: [Generated preview](dist/preview/index.html) · [Complete identity kit](dist/whocares-identity-kit.zip)

## Structure

```text
docs/                   Studio, identity, ownership and canonical usage guide
scripts/build.py        Deterministic generator and read-only verification
assets/logo/            Editable master and build documentation
assets/fonts/dm-mono/   Selected font, license and provenance
theme/                  Theme tokens, scripts, tests, adapters and documentation
theme/dist/             Generated theme package and identity-build inputs
assets/portraits/       Original photos and current website artwork
dist/symbol/{svg,png}/  Generated symbol artwork
dist/wordmark/{svg,png}/ Generated outlined wordmark artwork
dist/icons/             Favicons, Apple touch icon and avatar
dist/preview/           Offline preview and theme CSS
dist/                   Usage, license, integrity manifest and ZIP
```

## Build and verify

Requires Node 22+, npm, uv and Python 3.12+; uv resolves the script's pinned
dependencies. Theme has no third-party Node dependencies.

```sh
npm run build
npm test
npm run check
```

The root build generates theme first, then identity directly from `theme/dist/`.
Check verifies theme first, then identity without writing. Both `dist/` and
`theme/dist/` are ignored generated outputs; commit source, never build artifacts.
The theme workspace can also build, test and check independently.

## Coordinated releases

Both packages are version **0.4.0**. Keep their versions aligned for each fresh
release. Existing package names and export subpaths remain stable. They are
private packages distributed as `npm pack` archives, not registry publications.
From the repository root, with an existing absolute output directory:

```sh
npm run build
npm test
npm run check
npm pack --pack-destination "$RELEASE_DIR"
npm pack --workspace @whocaressoftware/theme --pack-destination "$RELEASE_DIR"
```

Root prepack builds theme and identity; theme prepack builds theme itself. These
commands produce `whocaressoftware-brand-0.4.0.tgz` and
`whocaressoftware-theme-0.4.0.tgz`. Consumers install both archives and commit
their dependency/lockfile updates. Neither build discovers or modifies consumers.
The former standalone theme repository is consolidated here, including its
working source changes. Its `.git` history/configuration is not nested here;
the redundant Taskfile's build/test/check commands are covered by npm scripts.
