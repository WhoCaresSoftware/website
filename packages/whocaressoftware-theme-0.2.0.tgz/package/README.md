# Who Cares Software theme

Design tokens and generated themes for Who Cares Software.
**Experimental palette: dark muted foundations with rose and orchid candidates.**
Initial colors take inspiration from Nocturne Rose. The founder selected orchid
(`#B69ACB`) as the primary accent after reviewing the comparison. Remaining
semantic roles and supporting colors are experimental; rose is a secondary candidate.

## Ownership

- [Brand wiki](https://github.com/WhoCaresSoftware/brand): story, assets, rationale and approval.
- Here: canonical machine-readable palette, semantic roles, adapters, generated exports.
- Consumers: their application behavior and normal theme activation.

## Build and verify

Node 22 or later; no dependencies to install.

```sh
npm run build
npm test
npm run check
```

Task equivalents: `mise exec task -- task generate` and `mise exec task -- task check`.
Generation is independent of the caller's directory and never reads consumer settings.

## Layout and contract

- `tokens/whocares.json`: named hex colors and semantic roles referencing palette keys.
- `tokens/website.json`: website palette extensions, light/dark roles and color recipes.
  Base palette names cannot be overridden. Mode roles must match and references
  must resolve. Generated `dist/website.{css,json}` is the website color interface.
- `scripts/`: runtime validation, reference resolution, rendering and freshness checks.
- `adapters/**/*.tmpl`: templates using `{{palette.rose}}` or `{{semantic.accent}}`.
- `dist/`: committed JSON, CSS, ESM, TypeScript declarations, and adapter outputs.

Token keys use kebab-case consistently. CSS primitives use `--wcs-palette-*`;
semantic variables use `--wcs-*`. Applications should prefer semantic roles.
JSON and JS include metadata and resolved palette/semantic groups.
Only `.tmpl` files are rendered, preserving their relative path minus that suffix.
Unknown references, malformed placeholders, duplicate outputs, and retired files fail.
Remove retired files explicitly after review. Check mode never writes.

Open `dist/preview/index.html` for a rose-versus-orchid comparison.
Preview typography and spacing are illustrative, not brand tokens.
The base theme provides dark color tokens; the website adapter provides both
light and dark treatments, including system-preference fallback. Theme owns all
executable color values; brand documents why they were chosen and consumes tokens
to generate identity assets. Consumer-owned imports never run from this generator.

The private package exports `.`, `./css`, and `./tokens.json`. It is not published
to npm. Consumers can copy committed outputs or use a pinned Git dependency.
