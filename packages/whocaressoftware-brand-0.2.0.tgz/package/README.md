# Who Cares Software — brand

**Who cares? We do.**

The canonical home for our studio story, brand decisions, profile, and identity assets.

- [Brand wiki](wiki/README.md)
- [Studio profile](wiki/PROFILE.md)
- [Decisions and current status](wiki/DECISIONS.md)
- [Asset library](assets/README.md)

The wiki is version-controlled Markdown in this repository. 

